# MoonPhase
#### Minecraft mod to display information about the state of the moon

F6 key to change icon position

![preview](https://cdn.discordapp.com/attachments/793769528441962537/1097901917457358958/2023-04-18_19.08.50.png "")
